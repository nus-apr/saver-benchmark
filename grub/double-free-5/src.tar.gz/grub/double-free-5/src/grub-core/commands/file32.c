#define GRUB_TARGET_WORDSIZE 32
#define XX		32
#define ehdrXX ehdr32
#define grub_file_check_netbsdXX grub_file_check_netbsd32
#include "fileXX.c"
