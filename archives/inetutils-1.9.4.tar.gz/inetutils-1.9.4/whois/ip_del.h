{
415236096UL, 4294705152UL, "whois.apnic.net"}

,
{
411303936UL, 4294705152UL, "whois.ripe.net"}

,
{
1023410176UL, 4278190080UL, "whois.apnic.net"}

,
{
1040187392UL, 4278190080UL, "whois.ripe.net"}

,
{
1070596096UL, 4294443008UL, "rr.level3.net"}

,
{
0UL, 3221225472UL, "whois.arin.net"}

,
{
2333343744UL, 4294705152UL, "whois.ripe.net"}

,
{
2333605888UL, 4294705152UL, "whois.ripe.net"}

,
{
2333868032UL, 4294836224UL, "whois.ripe.net"}

,
{
2365587456UL, 4290772992UL, "whois.ripe.net"}

,
{
2369781760UL, 4293918720UL, "whois.ripe.net"}

,
{
2370830336UL, 4294705152UL, "whois.ripe.net"}

,
{
2371092480UL, 4294836224UL, "whois.ripe.net"}

,
{
2447376384UL, 4293918720UL, "whois.ripe.net"}

,
{
2448424960UL, 4294443008UL, "whois.ripe.net"}

,
{
2448949248UL, 4294705152UL, "whois.ripe.net"}

,
{
2449211392UL, 4294836224UL, "whois.ripe.net"}

,
{
2449342464UL, 4294901760UL, "whois.ripe.net"}

,
{
2513043456UL, 4294836224UL, "whois.ripe.net"}

,
{
2513174528UL, 4294901760UL, "whois.ripe.net"}

,
{
2513305600UL, 4294836224UL, "whois.ripe.net"}

,
{
2513436672UL, 4293918720UL, "whois.ripe.net"}

,
{
2514485248UL, 4293918720UL, "whois.ripe.net"}

,
{
2515533824UL, 4294443008UL, "whois.ripe.net"}

,
{
2516058112UL, 4294705152UL, "whois.ripe.net"}

,
{
2533228544UL, 4294901760UL, "whois.ripe.net"}

,
{
2534211584UL, 4294901760UL, "whois.ripe.net"}

,
{
2534277120UL, 4294836224UL, "whois.ripe.net"}

,
{
2534408192UL, 4293918720UL, "whois.ripe.net"}

,
{
2535456768UL, 4292870144UL, "whois.ripe.net"}

,
{
2537553920UL, 4293918720UL, "whois.ripe.net"}

,
{
2538602496UL, 4294836224UL, "whois.ripe.net"}

,
{
2533556224UL, 4294901760UL, "whois.ripe.net"}

,
{
2533621760UL, 4294836224UL, "whois.ripe.net"}

,
{
2538733568UL, 4294901760UL, "whois.ripe.net"}

,
{
2539323392UL, 4294901760UL, "whois.ripe.net"}

,
{
2539388928UL, 4294836224UL, "whois.ripe.net"}

,
{
2539585536UL, 4294901760UL, "whois.ripe.net"}

,
{
2539847680UL, 4294901760UL, "whois.ripe.net"}

,
{
2698510336UL, 4294705152UL, "whois.ripe.net"}

,
{
2698772480UL, 4294901760UL, "whois.ripe.net"}

,
{
2687238144UL, 4294705152UL, "whois.ripe.net"}

,
{
2687500288UL, 4293918720UL, "whois.ripe.net"}

,
{
2744909824UL, 4294705152UL, "whois.ripe.net"}

,
{
2745171968UL, 4293918720UL, "whois.ripe.net"}

,
{
2751463424UL, 4292870144UL, "whois.ripe.net"}

,
{
2753560576UL, 4294443008UL, "whois.ripe.net"}

,
{
2754084864UL, 4294901760UL, "whois.ripe.net"}

,
{
2759852032UL, 4293918720UL, "whois.ripe.net"}

,
{
2848980992UL, 4293918720UL, "whois.apnic.net"}

,
{
2869952512UL, 4293918720UL, "whois.ripe.net"}

,
{
2871001088UL, 4294836224UL, "whois.ripe.net"}

,
{
3225878528UL, 4294901760UL, "whois.ripe.net"}

,
{
3225944064UL, 4294901760UL, "whois.seed.net.tw"}

,
{
3228209152UL, 4294963200UL, "whois.ripe.net"}

,
{
3228222464UL, 4294966784UL, "whois.ripe.net"}

,
{
3231842304UL, 4294901760UL, "whois.ripe.net"}

,
{
3231973376UL, 4294705152UL, "whois.ripe.net"}

,
{
3221225472UL, 4278190080UL, "whois.arin.net"}

,
{
3238002688UL, 4278190080UL, "whois.ripe.net"}

,
{
3254779904UL, 4261412864UL, "whois.ripe.net"}

,
{
3323032832UL, 4294967040UL, "whois.ripe.net"}

,
{
3288334336UL, 4227858432UL, "whois.arin.net"}

,
{
3355443200UL, 4261412864UL, "whois.arin.net"}

,
{
3405774848UL, 4290772992UL, "whois.aunic.net"}

,
{
3388997632UL, 4261412864UL, "whois.apnic.net"}

,
{
3422552064UL, 4227858432UL, "whois.arin.net"}

,
{
3489660928UL, 4261412864UL, "whois.arin.net"}

,
{
3523215360UL, 4261412864UL, "whois.apnic.net"}

,
{
3556769792UL, 4261412864UL, "whois.ripe.net"}

,
{
3590324224UL, 4261412864UL, "whois.arin.net"}

,
{
3623878656UL, 4278190080UL, "whois.arin.net"}

,
