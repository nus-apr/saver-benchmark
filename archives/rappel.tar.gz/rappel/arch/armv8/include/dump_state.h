void dump_state_armv8(
		const struct proc_info_t *const);
