void ptrace_collect_regs_armv8(
		const pid_t,
		struct proc_info_t *const);

void ptrace_reset_armv8(
		const pid_t,
		const unsigned long);
