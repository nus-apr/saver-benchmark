void dump_state_armv7(
		const struct proc_info_t *const);
