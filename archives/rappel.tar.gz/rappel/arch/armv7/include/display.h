void display_armv7(
		const struct proc_info_t *const);
