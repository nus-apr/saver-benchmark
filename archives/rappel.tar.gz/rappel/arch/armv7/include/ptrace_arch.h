void ptrace_collect_regs_armv7(
		const pid_t,
		struct proc_info_t *const);

void ptrace_reset_armv7(
		const pid_t,
		const unsigned long);
