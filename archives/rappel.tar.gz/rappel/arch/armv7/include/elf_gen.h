const
size_t gen_elf_armv7(
		uint8_t **,
		const unsigned long,
		const uint8_t *const,
		const size_t);
