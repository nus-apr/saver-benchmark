void dump_state_x86(
		const struct proc_info_t *const);
