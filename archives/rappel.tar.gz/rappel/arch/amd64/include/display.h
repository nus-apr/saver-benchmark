void display_amd64(
		const struct proc_info_t *const);
