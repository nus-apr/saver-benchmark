void ptrace_collect_regs_amd64(
		const pid_t,
		struct proc_info_t *const);

void ptrace_reset_amd64(
		const pid_t,
		const unsigned long);
