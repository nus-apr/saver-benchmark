void interact(
		const char *const);
