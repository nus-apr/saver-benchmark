void pipe_mode(void);
