#ifndef _GETSUBOPT_H
#define _GETSUBOPT_H
int getsubopt (char **optionp, char *const *tokens, char **valuep);
#endif
